#!/usr/bin/python3
"""
Unittest for the Console class
Test files by using the following command line:
python3 -m unittest tests/test_console.py
"""
import unittest
import pep8
from os import path, remove


class TestConsole(unittest.TestCase):
    """define variables and methods"""
    pass
